=== Plugin Name ===
Contributors: IntroSites
Donate link: 
Tags: plugin, page
Requires at least: 2.5.1
Tested up to: 2.8.4
Stable tag: trunk

Appends .html to the URL of PAGES when using permalinks

== Description ==

Appends .html to the URL of PAGES when using permalinks

== Installation ==

1. Upload html-on-pages.php to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



