# Wordpress_plugin
wordpress plugins: coding own plugins

1.auto-tag-to-title
- Auto add post tag to title.
- Format will be: [post-tag-name] title of post (example: [wp tips] How to filter a content).
- Tự động thêm tag vào tiêu đề bài viết.
- Tiêu đề sẽ tự động được thêm dạng [post-tag-name] trước tên bài viết (ví dụ: [wp tips] How to filter a content).
